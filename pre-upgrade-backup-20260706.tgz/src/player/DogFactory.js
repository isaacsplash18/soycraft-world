import * as THREE from 'three';

/**
 * Builds a cute low-poly dog from a breed param object (see config/breeds.js).
 * Returns a THREE.Group facing +Z with `group.userData.parts` (legs + tail) for
 * procedural animation by the Player.
 *
 * Style: smooth rounded shapes, a big head, big shiny eyes with highlights, and
 * a soft neck ruff for fluffy/curly breeds (no bumpy "fur balls"). A real rigged
 * GLB can still replace all of this via SETTINGS.assets.dogModel.
 */
export function buildDog(breed) {
  const g = new THREE.Group();
  g.name = `dog-${breed.id}`;

  const matBase = mat(breed.colors.base);
  const matBelly = mat(breed.colors.belly ?? breed.colors.base);
  const matEar = mat(breed.colors.ears ?? breed.colors.base);
  const matMask = breed.colors.mask != null ? mat(breed.colors.mask) : null;
  const matNose = mat(0x2a2422);
  const matEyeWhite = mat(0xfdfdfd);
  const matEye = mat(0x171311);
  const matHi = new THREE.MeshBasicMaterial({ color: 0xffffff });

  const { length, radius } = breed.body;
  const legLen = breed.legLength;
  const bodyY = legLen + radius * 0.8;
  const headR = radius * 1.05;
  const headZ = length / 2 + radius * 0.35;
  const headY = bodyY + radius * 0.5;

  // ── Torso (smooth capsule) ────────────────────────────────────────────────
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 8, 16), matBase);
  torso.rotation.x = Math.PI / 2;
  torso.position.set(0, bodyY, 0);
  g.add(torso);

  // lighter belly
  const belly = new THREE.Mesh(new THREE.CapsuleGeometry(radius * 0.78, length * 0.85, 6, 14), matBelly);
  belly.rotation.x = Math.PI / 2;
  belly.position.set(0, bodyY - radius * 0.32, radius * 0.1);
  belly.scale.y = 0.72;
  g.add(belly);

  // soft neck ruff for fluffy / curly coats — ONE smooth shape, not lumps
  if (breed.coat === 'fluffy' || breed.coat === 'curly') {
    const ruff = new THREE.Mesh(new THREE.SphereGeometry(radius * 1.2, 14, 12), matBase);
    ruff.position.set(0, bodyY + radius * 0.15, headZ - headR * 0.7);
    ruff.scale.set(1.15, 1.0, 0.9);
    g.add(ruff);
  }

  // ── Head ──────────────────────────────────────────────────────────────────
  const head = new THREE.Mesh(new THREE.SphereGeometry(headR, 18, 16), matBase);
  head.position.set(0, headY, headZ);
  head.scale.set(1, 0.96, 0.98);
  g.add(head);

  if (matMask) {
    const mask = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.99, 16, 14), matMask);
    mask.position.set(0, headY - headR * 0.12, headZ + headR * 0.5);
    mask.scale.set(0.92, 0.92, 0.5);
    g.add(mask);
  }

  // ── Muzzle + nose ───────────────────────────────────────────────────────
  const flat = breed.snout.flat;
  const sLen = breed.snout.length * (1 - flat * 0.7);
  const muzzle = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.5, 12, 10), matBelly);
  const muzzleZ = headZ + headR * 0.62 + sLen * 0.6;
  muzzle.position.set(0, headY - headR * 0.22, muzzleZ);
  muzzle.scale.set(1.05, 0.85, 1 + sLen * 2.2);
  g.add(muzzle);

  const nose = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.17, 10, 9), matNose);
  nose.position.set(0, headY - headR * 0.18, muzzleZ + headR * 0.5 + sLen * 0.6);
  nose.scale.set(1.2, 0.9, 0.9);
  g.add(nose);

  // ── Big cute eyes (white + pupil + highlight) ──────────────────────────────
  for (const sx of [-1, 1]) {
    const ex = sx * headR * 0.4;
    const ey = headY + headR * 0.14;
    const ez = headZ + headR * 0.82;
    const white = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.22, 12, 12), matEyeWhite);
    white.position.set(ex, ey, ez);
    white.scale.set(0.9, 1.05, 0.8);
    g.add(white);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.14, 10, 10), matEye);
    pupil.position.set(ex, ey, ez + headR * 0.12);
    g.add(pupil);
    const hi = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.05, 8, 8), matHi);
    hi.position.set(ex + sx * headR * 0.04, ey + headR * 0.07, ez + headR * 0.2);
    g.add(hi);
  }

  // ── Ears ──────────────────────────────────────────────────────────────────
  addEars(g, breed.ears, { headR, headY, headZ, matEar });

  // ── Legs (rounded, with paws; pivots at the hips for animation) ─────────────
  const legR = radius * 0.26;
  const legs = [];
  const legGeo = new THREE.CapsuleGeometry(legR, legLen * 0.55, 4, 8);
  const pawGeo = new THREE.SphereGeometry(legR * 1.15, 8, 7);
  const fz = length * 0.3;
  for (const [lx, lz] of [[-1, fz], [1, fz], [-1, -fz], [1, -fz]]) {
    const pivot = new THREE.Group();
    pivot.position.set(lx * radius * 0.62, bodyY - radius * 0.15, lz);
    const leg = new THREE.Mesh(legGeo, matEar);
    leg.position.y = -legLen * 0.45;
    const paw = new THREE.Mesh(pawGeo, matBelly);
    paw.position.y = -legLen * 0.82;
    paw.scale.set(1.1, 0.8, 1.2);
    pivot.add(leg, paw);
    g.add(pivot);
    legs.push(pivot);
  }

  // ── Tail (pivot for wagging) ──────────────────────────────────────────────
  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, bodyY + radius * 0.18, -length / 2 - radius * 0.25);
  addTail(tailPivot, breed.tail, { radius, matBase });
  g.add(tailPivot);

  // smooth shading + shadows
  g.traverse((c) => {
    if (c.isMesh) {
      c.castShadow = true;
      c.receiveShadow = true;
    }
  });

  g.userData.parts = { legs, tail: tailPivot, head };
  return g;
}

// ── helpers ──────────────────────────────────────────────────────────────────
function mat(hex) {
  return new THREE.MeshStandardMaterial({ color: hex, roughness: 0.7, metalness: 0 });
}

function addEars(g, type, { headR, headY, headZ, matEar }) {
  for (const sx of [-1, 1]) {
    let ear;
    switch (type) {
      case 'pointy':
        ear = new THREE.Mesh(new THREE.ConeGeometry(headR * 0.32, headR * 0.85, 12), matEar);
        ear.position.set(sx * headR * 0.52, headY + headR * 0.78, headZ - headR * 0.08);
        ear.rotation.z = sx * -0.18;
        break;
      case 'bat':
        ear = new THREE.Mesh(new THREE.ConeGeometry(headR * 0.42, headR * 0.95, 12), matEar);
        ear.position.set(sx * headR * 0.58, headY + headR * 0.82, headZ - headR * 0.04);
        ear.scale.z = 0.4;
        ear.rotation.z = sx * -0.22;
        break;
      case 'button':
        ear = new THREE.Mesh(new THREE.SphereGeometry(headR * 0.36, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), matEar);
        ear.position.set(sx * headR * 0.55, headY + headR * 0.55, headZ - headR * 0.02);
        ear.scale.set(0.8, 1.1, 0.5);
        ear.rotation.z = sx * 0.2;
        break;
      case 'butterfly':
        ear = new THREE.Mesh(new THREE.ConeGeometry(headR * 0.5, headR * 1.05, 12), matEar);
        ear.position.set(sx * headR * 0.68, headY + headR * 0.7, headZ - headR * 0.08);
        ear.scale.z = 0.32;
        ear.rotation.z = sx * -0.7;
        break;
      case 'floppy':
      default:
        ear = new THREE.Mesh(new THREE.CapsuleGeometry(headR * 0.28, headR * 0.6, 5, 10), matEar);
        ear.position.set(sx * headR * 0.6, headY + headR * 0.18, headZ - headR * 0.04);
        ear.scale.z = 0.55;
        ear.rotation.z = sx * 0.28;
        break;
    }
    g.add(ear);
  }
}

function addTail(pivot, type, { radius, matBase }) {
  let tail;
  switch (type) {
    case 'curl':
      tail = new THREE.Mesh(new THREE.TorusGeometry(radius * 0.42, radius * 0.16, 10, 16, Math.PI * 1.4), matBase);
      tail.position.y = radius * 0.4;
      tail.rotation.y = Math.PI / 2;
      break;
    case 'stubby':
      tail = new THREE.Mesh(new THREE.CapsuleGeometry(radius * 0.18, radius * 0.18, 5, 10), matBase);
      tail.position.set(0, radius * 0.12, -radius * 0.08);
      tail.rotation.x = -0.6;
      break;
    case 'plume':
      tail = new THREE.Mesh(new THREE.CapsuleGeometry(radius * 0.3, radius * 0.65, 6, 12), matBase);
      tail.position.set(0, radius * 0.5, -radius * 0.08);
      tail.rotation.x = -0.95;
      break;
    case 'straight':
    default:
      tail = new THREE.Mesh(new THREE.CapsuleGeometry(radius * 0.14, radius * 0.55, 5, 10), matBase);
      tail.position.set(0, radius * 0.28, -radius * 0.15);
      tail.rotation.x = -0.7;
      break;
  }
  pivot.add(tail);
}
