import * as THREE from 'three';
import { Capsule } from 'three/addons/math/Capsule.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { SETTINGS } from '../config/settings.js';
import { GRAVITY } from '../physics/Physics.js';
import { buildDog } from './DogFactory.js';
import { BREEDS, DEFAULT_BREED } from '../config/breeds.js';

/**
 * The player: a Capsule collider (so it can't pass through world geometry),
 * a third/first-person camera rig, and a visible character.
 *
 * Collision + camera-rig logic is adapted from the 3D-Game-Template-Ultimate
 * reference (player.js). The character is a procedural "dog" built from
 * primitives by default, structured so a rigged GLB swaps in cleanly.
 *
 * Input is fed in each frame via an `input` object (produced by Controls):
 *   input.move      THREE.Vector2-ish {x, y}  x=strafe(+right) y=forward(+fwd), each [-1,1]
 *   input.run       boolean
 *   input.consumeJump()   -> boolean (true once per jump press)
 *   input.consumeLook()   -> {dx, dy} look delta since last frame
 *   input.consumeZoom()   -> number (wheel delta since last frame)
 *   input.consumeViewToggle() -> boolean (true once per V press / button tap)
 */
export class Player {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;

    const p = SETTINGS.player;
    const r = p.capsuleRadius;
    const [sx, , sz] = p.startPosition;

    this.collider = new Capsule(
      new THREE.Vector3(sx, r, sz),
      new THREE.Vector3(sx, r + p.capsuleHeight, sz),
      r
    );
    this.velocity = new THREE.Vector3();
    this.onFloor = false;

    // Camera state (we own yaw/pitch; Controls feeds deltas).
    this.yaw = 0;
    this.pitch = 0.15;
    this.viewMode = 'third'; // 'third' | 'first'
    this.thirdDistance = 6;

    // Character model
    this.group = new THREE.Group();
    this.scene.add(this.group);
    this.mixer = null;
    this.actions = {};
    this.currentAction = null;
    this.modelReady = false;
    this.breedId = DEFAULT_BREED;
    this.dog = null; // current procedural dog group (null if a GLB is used)
    this._gait = 0; // animation phase accumulator
    this._barkT = 0; // bark animation countdown

    // scratch
    this._fwd = new THREE.Vector3();
    this._side = new THREE.Vector3();
    this._tmp = new THREE.Vector3();
    this._camTarget = new THREE.Vector3();
    this._camOffset = new THREE.Vector3();
    this._desiredForward = new THREE.Vector3();
    this._q = new THREE.Quaternion();

    this._loadCharacter();
  }

  // ── Character ─────────────────────────────────────────────────────────────
  _loadCharacter() {
    if (SETTINGS.assets.dogModel) {
      this._loadDogGLB(SETTINGS.assets.dogModel);
    } else {
      this.setBreed(this.breedId);
    }
  }

  /** Swap the visible dog to another breed (procedural). Cheap — rebuilds mesh. */
  setBreed(id) {
    const breed = BREEDS.find((b) => b.id === id) || BREEDS[0];
    this.breedId = breed.id;

    // Tear down the previous procedural dog (free its geometry/materials).
    if (this.dog) {
      this.group.remove(this.dog);
      this.dog.traverse((c) => {
        if (c.isMesh) {
          c.geometry?.dispose?.();
          if (Array.isArray(c.material)) c.material.forEach((m) => m.dispose?.());
          else c.material?.dispose?.();
        }
      });
    }

    this.dog = buildDog(breed);
    this.group.add(this.dog);
    this.modelReady = true;
    this.group.visible = this.viewMode === 'third';
  }

  /** List of selectable breeds, for the UI picker. */
  get breeds() {
    return BREEDS.map((b) => ({ id: b.id, name: b.name, size: b.size || 'small' }));
  }

  /** The full config for the current breed (used for bark pitch). */
  get currentBreed() {
    return BREEDS.find((b) => b.id === this.breedId) || BREEDS[0];
  }

  /** Trigger the bark animation (sound is played by main). */
  bark() {
    this._barkT = 0.5;
  }

  // Drop-in path: a rigged dog GLB. Looks for Idle / Walk / Run animation clips.
  _loadDogGLB(path) {
    new GLTFLoader().load(
      path,
      (gltf) => {
        const model = gltf.scene;
        model.traverse((c) => {
          if (c.isMesh) {
            c.castShadow = true;
            c.receiveShadow = true;
          }
        });
        model.scale.setScalar(SETTINGS.assets.dogScale);
        model.rotation.y = Math.PI; // face +Z
        this.group.add(model);

        if (gltf.animations?.length) {
          this.mixer = new THREE.AnimationMixer(model);
          for (const name of ['Idle', 'Walk', 'Run']) {
            const clip = THREE.AnimationClip.findByName(gltf.animations, name);
            if (clip) {
              const action = this.mixer.clipAction(clip);
              action.enabled = true;
              action.setEffectiveWeight(0);
              this.actions[name] = action;
            }
          }
          this._setAction('Idle');
        }
        this.modelReady = true;
        this.group.visible = this.viewMode === 'third';
      },
      undefined,
      (err) => {
        console.warn('Dog GLB failed to load, using procedural dog:', err);
        this.setBreed(this.breedId);
      }
    );
  }

  _setAction(name) {
    const next = this.actions[name];
    if (!next || this.currentAction === name) return;
    const prev = this.actions[this.currentAction];
    this.currentAction = name;
    next.reset();
    next.setEffectiveWeight(1);
    next.play();
    if (prev) prev.crossFadeTo(next, 0.3, true);
    else next.fadeIn(0.3);
  }

  // ── Per-frame update ───────────────────────────────────────────────────────
  update(dt, octree, input) {
    // view toggle (V / button)
    if (input.consumeViewToggle()) this._toggleView();

    // look
    const look = input.consumeLook();
    this.yaw -= look.dx / 500;
    this.pitch -= look.dy / 500;
    this._clampPitch();

    // zoom (third-person only)
    const zoom = input.consumeZoom();
    if (zoom && this.viewMode === 'third') {
      this.thirdDistance = THREE.MathUtils.clamp(this.thirdDistance + zoom * 0.0025, 2.5, 12);
    }

    // Velocity damping. Decay much faster when there's no movement input so the
    // player stops promptly instead of gliding ("auto-walking") after release.
    const moving = Math.abs(input.move.x) > 0.01 || Math.abs(input.move.y) > 0.01;
    let damping = Math.exp(-(moving ? 5 : 16) * dt) - 1;
    if (!this.onFloor) {
      this.velocity.y -= GRAVITY * dt;
      damping *= 0.1;
    }
    this.velocity.addScaledVector(this.velocity, damping);

    // movement intent -> acceleration
    this._applyMovement(dt, input);

    // Hard stop: once idle and slow on the ground, kill residual horizontal drift.
    if (!moving && this.onFloor && this.velocity.x ** 2 + this.velocity.z ** 2 < 0.05) {
      this.velocity.x = 0;
      this.velocity.z = 0;
    }

    // integrate + collide
    this.collider.translate(this._tmp.copy(this.velocity).multiplyScalar(dt));
    this._collide(octree);

    // visuals
    this._alignCharacter();
    this._updateCamera(dt);
    this._updateAnimation(dt, input);
    this._teleportIfOob();
  }

  _applyMovement(dt, input) {
    const p = SETTINGS.player;
    const moving = Math.abs(input.move.x) > 0.01 || Math.abs(input.move.y) > 0.01;
    const running = input.run && moving;
    const speed = (this.onFloor ? 1 : 0.4) * (running ? p.runSpeed : p.walkSpeed);
    const accel = dt * speed;

    // forward/side derived from yaw (flat plane)
    this._fwd.set(Math.sin(this.yaw), 0, Math.cos(this.yaw)).multiplyScalar(-1);
    // Right vector = forward × up = (-fwd.z, 0, fwd.x). (The flipped sign here
    // was inverting A/D and the joystick's left/right.)
    this._side.set(-this._fwd.z, 0, this._fwd.x);

    if (moving) {
      this.velocity.addScaledVector(this._fwd, input.move.y * accel);
      this.velocity.addScaledVector(this._side, input.move.x * accel);
    }

    if (this.onFloor && input.consumeJump()) {
      this.velocity.y = p.jumpSpeed;
    }
  }

  _collide(octree) {
    const result = octree.capsuleIntersect(this.collider);
    this.onFloor = false;
    if (result) {
      this.onFloor = result.normal.y > 0;
      if (!this.onFloor) {
        this.velocity.addScaledVector(result.normal, -result.normal.dot(this.velocity));
      }
      if (result.depth >= 1e-10) {
        this.collider.translate(result.normal.multiplyScalar(result.depth));
      }
    }
  }

  _alignCharacter() {
    if (!this.modelReady) return;
    const base = this._tmp.copy(this.collider.start);
    base.y -= this.collider.radius;
    this.group.position.lerp(base, 0.3);

    // face movement direction
    const hv = this._desiredForward.set(this.velocity.x, 0, this.velocity.z);
    if (hv.lengthSq() > 0.05) {
      hv.normalize();
      this._q.setFromUnitVectors(new THREE.Vector3(0, 0, 1), hv);
      this.group.quaternion.slerp(this._q, 0.2);
    }
  }

  _updateCamera(dt) {
    if (this.viewMode === 'third') {
      // Orbit behind the dog and look at it.
      this._camTarget.copy(this.collider.end);
      this._camTarget.y += 0.2;
      this._camOffset.set(0, 2.4, this.thirdDistance);
      this._camOffset.applyEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'));
      const desired = this._tmp.copy(this._camTarget).add(this._camOffset);
      this.camera.position.lerp(desired, THREE.MathUtils.clamp(dt * 10, 0, 1));
      this.camera.lookAt(this._camTarget);
      if (this.modelReady) this.group.visible = true;
    } else {
      // First-person: sit at the dog's eye level and look ALONG yaw/pitch
      // (not at the head — that made the view stare at the ground).
      this._camTarget.copy(this.collider.end);
      this._camTarget.y += 0.05;
      this.camera.position.lerp(this._camTarget, THREE.MathUtils.clamp(dt * 18, 0, 1));
      const cp = Math.cos(this.pitch);
      const lookX = this.camera.position.x - Math.sin(this.yaw) * cp;
      const lookY = this.camera.position.y + Math.sin(this.pitch);
      const lookZ = this.camera.position.z - Math.cos(this.yaw) * cp;
      this.camera.lookAt(lookX, lookY, lookZ);
      if (this.modelReady) this.group.visible = false;
    }
  }

  _updateAnimation(dt, input) {
    // GLB path: drive the animation mixer (Idle/Walk/Run).
    if (this.mixer) {
      this.mixer.update(dt);
      const moving = Math.abs(input.move.x) > 0.01 || Math.abs(input.move.y) > 0.01;
      if (this.onFloor) this._setAction(!moving ? 'Idle' : input.run ? 'Run' : 'Walk');
      return;
    }
    // Procedural dog: swing legs with speed, wag the tail.
    this._animateDog(dt);
  }

  _animateDog(dt) {
    const parts = this.dog?.userData.parts;
    if (!parts) return;

    const speed = Math.hypot(this.velocity.x, this.velocity.z);
    const moving = speed > 0.3;
    this._gait += dt * (moving ? 6 + speed * 0.5 : 4);

    // Legs trot in diagonal pairs (FL+BR vs FR+BL).
    const swing = moving ? Math.min(speed * 0.06, 0.7) : 0;
    parts.legs.forEach((leg, i) => {
      const phase = i === 0 || i === 3 ? this._gait : this._gait + Math.PI;
      leg.rotation.x = Math.sin(phase) * swing;
    });

    // Tail wags faster when moving / happy.
    let wagAmp = moving ? 0.5 : 0.28;
    let wagSpeed = moving ? 1.6 : 0.9;

    // Bark: head jerks up, tail wags hard, body bounces — for ~0.5s.
    if (this._barkT > 0) {
      this._barkT -= dt;
      const ph = (0.5 - this._barkT) * 34;
      if (parts.head) parts.head.rotation.x = -Math.abs(Math.sin(ph)) * 0.4; // snout up
      wagAmp = 0.9;
      wagSpeed = 5;
      if (this.dog) this.dog.position.y = Math.abs(Math.sin(ph)) * 0.08;
    } else {
      if (parts.head) parts.head.rotation.x *= 0.7; // settle back
      if (this.dog) this.dog.position.y = moving ? Math.abs(Math.sin(this._gait)) * 0.04 : 0;
    }

    parts.tail.rotation.y = Math.sin(this._gait * wagSpeed) * wagAmp;
  }

  _toggleView() {
    this.viewMode = this.viewMode === 'third' ? 'first' : 'third';
    this.pitch = this.viewMode === 'third' ? 0.15 : 0;
    this._clampPitch();
    if (this.modelReady) this.group.visible = this.viewMode === 'third';
  }

  _clampPitch() {
    const max = this.viewMode === 'third' ? Math.PI / 4 : Math.PI / 2 - 0.1;
    const min = this.viewMode === 'third' ? -Math.PI / 3 : -Math.PI / 2 + 0.1;
    this.pitch = THREE.MathUtils.clamp(this.pitch, min, max);
  }

  _teleportIfOob() {
    if (this.collider.end.y > -25) return;
    const r = SETTINGS.player.capsuleRadius;
    this.collider.start.set(0, r, 0);
    this.collider.end.set(0, r + SETTINGS.player.capsuleHeight, 0);
    this.velocity.set(0, 0, 0);
  }

  /** Player world position (feet), reused by Products proximity checks. */
  get position() {
    return this.collider.start;
  }
}
