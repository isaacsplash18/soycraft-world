import * as THREE from 'three';

import { createScene } from './core/SceneSetup.js';
import { Sky } from './world/Sky.js';
import { DogVision } from './world/DogVision.js';
import { Links } from './world/Links.js';
import { Bark } from './world/Bark.js';
import { World } from './core/World.js';
import { Physics } from './physics/Physics.js';
import { Player } from './player/Player.js';
import { Controls } from './controls/Controls.js';
import { Products } from './products/Products.js';
import { UI } from './ui/UI.js';
import { PRODUCTS } from './config/products.js';

/**
 * Soycraft World — entry point.
 *
 * Wires the modules together and runs a fixed-timestep loop (the same pattern
 * as the 3D-Game-Template-Ultimate reference: physics is stepped N times per
 * rendered frame for stable collision regardless of framerate).
 */
const STEPS_PER_FRAME = 5;
const clock = new THREE.Clock();

async function boot() {
  // 1. Renderer / scene / camera
  const { scene, camera, renderer, sun, hemi } = createScene();
  document.getElementById('container').appendChild(renderer.domElement);

  // Time-of-day sky (day / golden hour / night) based on the user's local clock.
  const sky = new Sky({ scene, renderer, sun, hemi });

  // 2. Input + UI
  const controls = new Controls(renderer.domElement);
  const ui = new UI({ controls });
  ui.setTotal(PRODUCTS.length);

  // 3. World (placeholder park or GLB) -> collidable group
  const world = new World(scene);
  const collidables = await world.build();
  sky.apply(sky.presetName); // sync night lamps/emissives created during build
  ui.setProgress(60);

  // 4. Product props (added into the same collidable group)
  const products = new Products(scene, {
    onEnterRange: (product) => ui.showCard(product),
    onLeaveRange: () => ui.hideCard(),
    onDiscover: (count, total) => {
      ui.setCount(count);
      if (count >= total) {
        // Let the player read the final card, then celebrate.
        setTimeout(() => ui.showCompletion(), 1300);
      }
    },
  });
  products.build(collidables);

  // 4b. External link points (shop, Fur Away Journey, Instagram) — not counted
  // toward discovery.
  const links = new Links(scene, {
    onEnter: (link) => ui.showLinkCard(link),
    onLeave: () => ui.hideLinkCard(),
  });
  links.build(collidables);
  ui.setProgress(80);

  // 5. Physics — build the Octree from everything collidable
  const physics = new Physics();
  physics.buildFrom(collidables);
  physics.attachHelper(scene);

  // 6. Player (capsule + camera rig + character)
  const player = new Player(scene, camera);

  // Dog-vision post-processing (only rendered in first-person).
  const dogVision = new DogVision(renderer, scene, camera);

  // Breed picker — populate from the player's breed list, switch on change.
  ui.setupBreedPicker(player.breeds, player.breedId, (id) => player.setBreed(id));

  // Start screen — the player picks a breed before exploring. Until they hit
  // "Start", the world renders (dog on show) but movement/interaction is frozen.
  let started = false;
  ui.setupStartScreen(
    player.breeds,
    player.breedId,
    (id) => {
      player.setBreed(id);
      const picker = document.getElementById('breed-select');
      if (picker) picker.value = id; // keep the in-game picker in sync
    },
    () => {
      started = true;
    }
  );

  // Bark button (+ B key) — synth bark pitched to the breed, plus an animation.
  const bark = new Bark();
  const doBark = () => {
    bark.play(player.currentBreed);
    player.bark();
  };
  ui.setupBark(doBark);

  // Unlock audio on the very first user interaction (required on iOS/mobile).
  const unlockAudio = () => bark.unlock();
  ['touchstart', 'pointerdown', 'mousedown', 'keydown'].forEach((ev) =>
    window.addEventListener(ev, unlockAudio, { once: true, passive: true })
  );

  ui.setProgress(100);
  ui.hideLoading();

  // Dev-only debug hook (handy for testing / tweaking; no effect in play).
  if (import.meta.env?.DEV) {
    window.__soy = { scene, camera, renderer, player, products, links, controls, physics, ui, sky, dogVision };
  }

  // Keyboard: H toggles the Octree wireframe, B barks.
  window.addEventListener('keydown', (e) => {
    const typing = e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA');
    if (typing) return;
    if (e.code === 'KeyH' && !e.repeat) physics.toggleHelper();
    if (e.code === 'KeyB' && !e.repeat) doBark();
  });

  // 7. Loop
  function animate() {
    const frameDelta = Math.min(0.05, clock.getDelta());
    const dt = frameDelta / STEPS_PER_FRAME;

    // Before "Start": freeze movement/input so the dog just stands on show.
    if (started) controls.update();
    else {
      controls.input.move.x = 0;
      controls.input.move.y = 0;
    }

    for (let i = 0; i < STEPS_PER_FRAME; i++) {
      player.update(dt, physics.octree, controls.input);
    }

    sky.update(frameDelta);

    if (started) {
      products.update(frameDelta, player.position);
      links.update(frameDelta, player.position);

      // E (or the mobile Shop button) opens whatever you're standing next to —
      // a product page, or an external link point (shop / partner / Instagram).
      if (controls.input.consumeInteract()) {
        if (products.activeProduct) window.open(products.activeProduct.shopUrl, '_blank', 'noopener');
        else if (links.activeLink) window.open(links.activeLink.url, '_blank', 'noopener');
      }
    }

    // First-person renders through the dog-vision filter; third-person renders
    // straight (no post-processing cost when you don't need it).
    if (player.viewMode === 'first') dogVision.render(1);
    else renderer.render(scene, camera);
  }

  renderer.setAnimationLoop(animate);
}

boot().catch((err) => {
  console.error('Failed to start Soycraft World:', err);
  const msg = document.querySelector('.loading-text');
  if (msg) msg.textContent = 'Something went wrong loading the game.';
});
