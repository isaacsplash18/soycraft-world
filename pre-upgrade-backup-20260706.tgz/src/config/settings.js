/**
 * ============================================================================
 *  GAME SETTINGS  —  world size, asset hooks, tuning knobs
 * ============================================================================
 *  Product data lives in products.js. This file holds everything else:
 *  asset swap-in paths, world dimensions, and gameplay tuning.
 * ============================================================================
 */

/**
 * Soycraft brand palette — extracted from the live theme at soycraft.co.
 * Minimal / luxe: near-black ink, soft greys, a coral accent, warm neutrals.
 * Used across the 3D scene and the UI so the game matches the site.
 */
export const BRAND = {
  ink: 0x1c1b1b, // headings / text
  subInk: 0x6a6a6a, // light text / links
  accent: 0xf94c43, // coral (sale/CTA accent on the site)
  cream: 0xf4f1ea, // warm off-white
  sand: 0xe7e0d3, // ground tone
  mauve: 0xd9d3d5, // soft brand grey-mauve
  sage: 0xb9c4ad, // muted foliage
  sageDark: 0x9aa888,
  white: 0xffffff,
  sky: 0xf3eee6, // soft warm horizon (also fog color)
  // CSS string helpers for the UI layer
  css: {
    ink: '#1c1b1b',
    subInk: '#6a6a6a',
    accent: '#f94c43',
    cream: '#f4f1ea',
    border: '#e9e5dd',
  },
};

export const SETTINGS = {
  // --- ASSET HOOKS --------------------------------------------------------
  // Leave a path null to use the built-in placeholder. Set a path to load a GLB.
  assets: {
    // TODO: Drop a low-poly park/garden GLB in /public/world/ and point here,
    //       e.g. '/world/soycraft-park.glb'. When set, the procedural primitive
    //       world is skipped and collision is built from the GLB instead.
    worldModel: null,

    // TODO: Drop a rigged dog GLB in /public/character/ and point here,
    //       e.g. '/character/soycraft-dog.glb'. Animation clip names the player
    //       looks for are listed in player/Player.js (Idle / Walk / Run).
    dogModel: null,
    dogScale: 1.0,
  },

  // --- WORLD --------------------------------------------------------------
  world: {
    halfSize: 44, // ground extends from -halfSize..+halfSize on X and Z
    groundColor: BRAND.sand, // soft warm neutral (brand)
    skyColor: BRAND.sky, // warm off-white (also the fog color)
    fogNear: 55,
    fogFar: 165, // far enough to see the snow mountain on the horizon
    treeCount: 16, // instanced low-poly trees (muted sage) filling the gaps
    bushCount: 22, // instanced low-poly bushes
  },

  // --- PLAYER -------------------------------------------------------------
  player: {
    startPosition: [0, 0, 16], // spawn facing the central logo (-Z)
    walkSpeed: 26,
    runSpeed: 44,
    jumpSpeed: 12,
    capsuleRadius: 0.4,
    capsuleHeight: 1.2, // distance between capsule start/end spheres
  },

  // --- PRODUCTS -----------------------------------------------------------
  products: {
    interactRadius: 3.4, // how close (meters) the player must get to discover
    labelHeight: 2.1, // floating label height above a product
  },

  // --- PERFORMANCE --------------------------------------------------------
  perf: {
    maxPixelRatioMobile: 1.5, // cap DPR on phones to keep fps high
    maxPixelRatioDesktop: 2.0,
    shadows: true, // turned off automatically on low-power devices
  },
};

// Simple touch / mobile detection used across modules.
export const IS_TOUCH =
  typeof window !== 'undefined' &&
  ('ontouchstart' in window || (navigator.maxTouchPoints || 0) > 0);
