import { IS_TOUCH } from '../config/settings.js';

/**
 * All DOM / 2D overlay handling:
 *   • loading screen progress
 *   • HUD discovery counter
 *   • product info card (name, description, image, shop link)
 *   • completion overlay + email capture
 *   • mobile action buttons (jump, switch view)
 *
 * No game logic lives here — main.js drives it via these methods.
 */
export class UI {
  constructor({ controls, onReplay } = {}) {
    this.controls = controls;
    this.onReplay = onReplay;
    this._completed = false;

    // Elements
    this.loadingScreen = document.getElementById('loading-screen');
    this.loadingProgress = document.querySelector('.loading-progress');
    this.countEl = document.getElementById('discovery-count');
    this.totalEl = document.getElementById('discovery-total');

    this.card = document.getElementById('product-card');
    this.cardImg = document.getElementById('product-card-img');
    this.cardCat = document.getElementById('product-card-cat');
    this.cardName = document.getElementById('product-card-name');
    this.cardDesc = document.getElementById('product-card-desc');
    this.cardPrice = document.getElementById('product-card-price');
    this.cardShop = document.getElementById('product-card-shop');
    document.getElementById('product-card-close').addEventListener('click', () => this.hideCard());

    // Link card (external links — shop, Fur Away Journey, Instagram)
    this.linkCard = document.getElementById('link-card');
    this.linkTag = document.getElementById('link-card-tag');
    this.linkTitle = document.getElementById('link-card-title');
    this.linkSub = document.getElementById('link-card-sub');
    this.linkCta = document.getElementById('link-card-cta');
    this.linkIcon = document.getElementById('link-card-icon');
    document.getElementById('link-card-close').addEventListener('click', () => this.hideLinkCard());

    this.completion = document.getElementById('completion');
    this.emailForm = document.getElementById('email-form');
    this.emailInput = document.getElementById('email-input');
    this.emailMsg = document.getElementById('email-msg');
    this.emailForm.addEventListener('submit', (e) => this._onEmailSubmit(e));
    document
      .getElementById('completion-replay')
      .addEventListener('click', () => this.hideCompletion());

    if (IS_TOUCH) this._buildMobileButtons();

    // Hide desktop/mobile hint variants per device.
    document.body.classList.add(IS_TOUCH ? 'is-touch' : 'is-desktop');
  }

  // ── Loading ────────────────────────────────────────────────────────────────
  setProgress(pct) {
    if (this.loadingProgress) this.loadingProgress.textContent = `${Math.round(pct)}%`;
  }

  hideLoading() {
    if (!this.loadingScreen) return;
    this.loadingScreen.classList.add('fade-out');
    setTimeout(() => (this.loadingScreen.style.display = 'none'), 500);
  }

  // ── HUD counter ──────────────────────────────────────────────────────────
  setTotal(n) {
    if (this.totalEl) this.totalEl.textContent = n;
  }

  setCount(n) {
    if (this.countEl) {
      this.countEl.textContent = n;
      // tiny pop animation
      this.countEl.classList.remove('pop');
      void this.countEl.offsetWidth;
      this.countEl.classList.add('pop');
    }
  }

  // ── Product card ─────────────────────────────────────────────────────────
  showCard(product) {
    if (this._completed) return; // don't pop cards over the finish screen
    this.cardCat.textContent = (product.category || '').toUpperCase();
    this.cardName.textContent = product.name;
    this.cardDesc.textContent = product.description;
    this.cardPrice.textContent = product.price || '';
    this.cardShop.href = product.shopUrl;
    this.cardImg.src = product.image;
    this.cardImg.alt = product.name;
    this.card.classList.remove('hidden');
  }

  hideCard() {
    this.card.classList.add('hidden');
  }

  // ── Link card (external links) ─────────────────────────────────────────────
  showLinkCard(link) {
    if (this._completed) return;
    this.linkTag.textContent = link.tag || 'LINK';
    this.linkTitle.textContent = link.title;
    this.linkSub.textContent = link.subtitle;
    this.linkCta.textContent = link.cta || 'Open →';
    this.linkCta.href = link.url;
    this.linkIcon.textContent = link.icon || '↗';
    this.linkCard.classList.remove('hidden');
  }

  hideLinkCard() {
    this.linkCard.classList.add('hidden');
  }

  // ── Completion + email capture ───────────────────────────────────────────
  showCompletion() {
    this._completed = true;
    this.hideCard();
    this.completion.classList.remove('hidden');
  }

  hideCompletion() {
    this.completion.classList.add('hidden');
  }

  _onEmailSubmit(e) {
    e.preventDefault();
    const email = this.emailInput.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this.emailMsg.textContent = 'Please enter a valid email.';
      this.emailMsg.className = 'email-msg error';
      return;
    }

    // ────────────────────────────────────────────────────────────────────
    // TODO: WIRE UP REAL EMAIL CAPTURE HERE.
    // Replace this stub with a POST to your provider, e.g. Klaviyo /
    // Mailchimp / Shopify customer endpoint:
    //
    //   await fetch('https://your-endpoint', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ email, source: 'soycraft-world-game' }),
    //   });
    // ────────────────────────────────────────────────────────────────────
    console.log('[Soycraft] captured email (placeholder):', email);

    this.emailMsg.textContent = "🎉 You're on the list! We'll be in touch.";
    this.emailMsg.className = 'email-msg success';
    this.emailInput.disabled = true;
    this.emailForm.querySelector('button').disabled = true;
  }

  // ── Start screen (breed selection before play) ─────────────────────────────
  setupStartScreen(breeds, currentId, onChange, onStart) {
    const screen = document.getElementById('start-screen');
    const select = document.getElementById('start-breed-select');
    const groups = {
      small: Object.assign(document.createElement('optgroup'), { label: 'Small dogs' }),
      big: Object.assign(document.createElement('optgroup'), { label: 'Big dogs' }),
    };
    for (const b of breeds) {
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = b.name;
      if (b.id === currentId) opt.selected = true;
      (groups[b.size] || groups.small).appendChild(opt);
    }
    select.appendChild(groups.small);
    select.appendChild(groups.big);
    select.addEventListener('change', () => onChange(select.value));

    document.getElementById('start-btn').addEventListener('click', () => {
      screen.classList.add('hidden');
      document.body.classList.remove('pre-start');
      onStart();
    });

    document.body.classList.add('pre-start'); // hides HUD/controls until start
    screen.classList.remove('hidden');
  }

  // ── Breed picker ───────────────────────────────────────────────────────────
  setupBreedPicker(breeds, currentId, onChange) {
    const wrap = document.createElement('div');
    wrap.id = 'breed-picker';

    const label = document.createElement('span');
    label.className = 'breed-label';
    label.textContent = '🐶 Breed';

    const select = document.createElement('select');
    select.id = 'breed-select';
    select.setAttribute('aria-label', 'Choose dog breed');
    const groups = {
      small: Object.assign(document.createElement('optgroup'), { label: 'Small dogs' }),
      big: Object.assign(document.createElement('optgroup'), { label: 'Big dogs' }),
    };
    for (const b of breeds) {
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = b.name;
      if (b.id === currentId) opt.selected = true;
      (groups[b.size] || groups.small).appendChild(opt);
    }
    select.appendChild(groups.small);
    select.appendChild(groups.big);
    select.addEventListener('change', () => onChange(select.value));

    wrap.appendChild(label);
    wrap.appendChild(select);
    document.body.appendChild(wrap);
  }

  // ── Bark button (desktop + mobile) ─────────────────────────────────────────
  setupBark(onBark) {
    const btn = document.createElement('button');
    btn.id = 'bark-btn';
    btn.innerHTML = '🐶 Bark!';
    btn.setAttribute('aria-label', 'Bark');
    // pointerdown fires once for mouse + touch and is a valid gesture for
    // unlocking audio on mobile (click can be too late / get swallowed).
    btn.addEventListener(
      'pointerdown',
      (e) => {
        e.preventDefault();
        btn.classList.remove('pop');
        void btn.offsetWidth;
        btn.classList.add('pop');
        onBark();
      },
      { passive: false }
    );
    document.body.appendChild(btn);
  }

  // ── Mobile action buttons ────────────────────────────────────────────────
  _buildMobileButtons() {
    const wrap = document.createElement('div');
    wrap.id = 'mobile-buttons';

    const jump = document.createElement('button');
    jump.className = 'm-btn';
    jump.textContent = '⤒';
    jump.setAttribute('aria-label', 'Jump');
    jump.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.controls?.pressJump();
    });

    const view = document.createElement('button');
    view.className = 'm-btn';
    view.textContent = '👁';
    view.setAttribute('aria-label', 'Switch view');
    view.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.controls?.pressViewToggle();
    });

    wrap.appendChild(view);
    wrap.appendChild(jump);
    document.body.appendChild(wrap);
  }
}
